############# reading realesate.csv and inserting all the records to the db
import pymysql
import time
import os
import csv
try:
    # creating file with today's timestamp
    filename = "realestate.csv"
    #connect database

    db = pymysql.connect(host="127.0.0.1",port=3306,user='root',password='india@123',database = 'wells') 
    #print(db)   # check the connection if successful or not
    if db:  
        # for accessing the records
        cursor = db.cursor()
        # verifying whether the file is existing o nor
        if os.path.exists(filename):    
            with open(filename,"r") as fobj:
                # converting file object to csv object
                reader = csv.reader(fobj)
                for line in reader:
                    if "SACRAMENTO":
                        query = "insert into realestate values('{}','{}')".format(line[0],line[1])
                        cursor.execute(query)
                        db.commit() 
        else:
            print(filename, "not existing")
    else:
        print("failed connecting to datbase")
        
except pymysql.InterfaceError as err:
    print(err)
except pymysql.DatabaseError as err:
    print(err)
except pymysql.IntegrityError as err:
    print(err)        
except (pymysql.MySQLError,pymysql.OperationalError) as err:
    print(err)
except Exception as err:
    print(err)