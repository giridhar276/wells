import getopt, sys, os, errno  
import getpass    
import requests
import json

server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"

print("checking ", url, "using user:", user)

local_file = "customer.csv"
with open(local_file) as fh:
    mydata = fh.read()

payload = {
  "description": "sample csv file",
  "public": "true",
  "files": {
    local_file: {
      "content": mydata
    }
  }
}
r1 = requests.post(url, data=json.dumps(payload), auth=(user,"9ef89321ec1f8188c4b45fbc67db836da8ede3cf"))
print(r1.json())


