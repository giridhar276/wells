import pickle

# final output
dictdata = {"chap1":10 ,"chap2":20 ,"chap3":30,"chap4":40}

# pickle file
filename = 'books.pkl'
outfile = open(filename,'wb')
# writing to the pickle file
pickle.dump(dictdata,outfile)
outfile.close()



#Deserialization:
## Unpickling
infile = open(filename,'rb')
# reading from the file
new_dict = pickle.load(infile)
infile.close()

print("Output:", new_dict)