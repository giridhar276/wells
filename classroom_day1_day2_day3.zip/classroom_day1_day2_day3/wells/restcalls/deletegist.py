import getopt, sys, os, errno  
import getpass    
import requests
import json
from requests.auth import HTTPBasicAuth

server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"
#passwd = getpass.getpass('Password:')
print("checking ", url, "using user:", user)

gid = '523765d995ea4225a9e3486646efabc0'
url = server + "/gists/" + gid

r1 = requests.delete(url, auth=HTTPBasicAuth(user,'8f7dd3f65c4c60f1b57f8ec8f15b692fe28d70cb'))
print(r1)
print(r1.text)
