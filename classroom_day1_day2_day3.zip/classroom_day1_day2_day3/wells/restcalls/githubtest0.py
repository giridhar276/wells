import requests
import json
r = requests.get('https://api.github.com', auth=('giridhar276',''))
print(r.status_code)


info = json.loads(r.text)
for key in info:
    print(key.ljust(20) , ":"  , info[key])
