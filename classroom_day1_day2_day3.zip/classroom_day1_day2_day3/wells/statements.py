
##### simple if
name = input("Enter any string :")

if name.isupper():
    print("String is upper")
    print("Inside indentation")
    print("Still inside identation")
print("Out of indentaion")


# if-else
if name.isupper():
    print("String is upper")
else:
    print("lower")
    
    
# if-elif-eli-elif... else
    
color = input("Enter any color:").lower()
if color == "red":
    print("Red")
elif color == "green":
    print("Green")
elif color == "black":
    print("Back")
else :
    print("Undefined color")
    