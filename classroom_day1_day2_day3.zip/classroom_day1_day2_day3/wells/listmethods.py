alist = [10,20,43,45,3,5,443354,3,54]


print(alist)
# append : adding one object
alist.append(450)
print("After appending:", alist)
alist.append(456)
print("After appending:", alist)

# adding an iterable
alist.extend([45,4,5,4,56,4,33])
print("After extending:", alist)


# insert(where to insert, what to insert)
# insert(index number, value)
alist.insert(0,500)
print("After inserting :", alist)

alist.pop()  # will remove the last value by default( if index is not passed)
print(alist)

alist.pop(0)
print(alist)

alist.reverse()
print("After reverse :", alist)

alist.sort()
print("After sorting :", alist)





