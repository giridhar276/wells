
# set operations
aset = {10,10,20,30,40}
bset = {30,40,50,50,50,50,50}

# union operation
print(aset.union(bset))
# A - B
print(aset.difference(bset))

print(aset.intersection(bset))