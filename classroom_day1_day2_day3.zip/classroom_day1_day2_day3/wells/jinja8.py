#start by importing the Template function from jinja2

#https://codingpackets.com/blog/jinja2-for-network-engineers/
from jinja2 import Template

#Set up the jinja template
with open("walan3.j2") as file:
    jtemplate = Template(file.read())

#Create a variable along with some logic to generate the configuration
output = jtemplate.render(intf="Ethernet1/0",intdscr="WAN_byJinja",ip="10.1.1.1",
                          mask="255.255.255.252", qospol="200MB_SHAPE",bgpasn="65456",
                          bgpnip="10.1.1.2",remasn="65499")
print(output)