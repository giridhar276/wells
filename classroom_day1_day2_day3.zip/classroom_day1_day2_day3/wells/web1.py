
from bs4 import BeautifulSoup  
import requests
## step 1: requests library to used to connect with http
url = "https://www.google.com/"
response= requests.get(url)


## step2: beautifulsoup ( transforming web info to meaningingformat)
#print(response.text)
### reading the html string to the soup object
soup = BeautifulSoup(response.text, 'html.parser')

#print(soup.title)

for link in soup.find_all('a'):
    print(link.get('href'))