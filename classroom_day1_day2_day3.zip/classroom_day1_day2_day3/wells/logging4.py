import logging

logging.basicConfig(filename='test3.log', format='%(asctime)s      %(filename)s: %(message)s',level=logging.ERROR)

logging.debug('This is a debug message')
logging.info('This is an info message')
logging.warning('This is a warning message')
logging.error('This is an error message')
logging.critical('This is a critical message')
