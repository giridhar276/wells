

atup = (10,30,45)

atup.