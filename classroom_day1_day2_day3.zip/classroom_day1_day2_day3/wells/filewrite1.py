
# fobj = open("D:\\new\\customer.txt","w")
# fobj = open(r"D:\new\customer.txt","w")   #raw string
# fobj = open("D:/new/customer.txt","w")

# traditional way
fobj = open("D:\new\customer.txt","w")
# writing to the file

for val in range(1,11):
    fobj.write(str(val) + "\n")

# closing the object
fobj.close()

## modern way
## context manager
# if any lines starts with the keyword with ... it is known as context manager
## file will be closed automatically
## file will be closed automaticall when it comes out of indentation
name = "Ram,,27,Hyderabad"
with open("customer.csv","w") as fobj:
    for val in range(1,11):
        fobj.write(name + "\n")
        
# database
# ssh, sftp
# ftp, telnet
    





