import ipaddress as ip

net4 = ip.ip_network('10.0.1.0/24')

print(net4)

print(net4.netmask)

all_hosts = list(net4.hosts())

for host in all_hosts:
    print(host)



pip install dnspython
