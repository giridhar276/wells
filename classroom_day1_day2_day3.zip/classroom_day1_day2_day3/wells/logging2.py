import logging
import time
file = time.strftime("%d_%b_%Y.log")
logging.basicConfig(level=logging.ERROR, filename=file)


kwargs = {'a':3, 'b':4}

logging.debug("a = {a}, b = {b}".format(**kwargs))
logging.info("Hypotenuse of {a}, {b}".format(**kwargs))
logging.warning("a={a} and b={b} are equal".format(**kwargs))
logging.warning("test")
logging.error("a={a} and b={b} cannot be negative".format(**kwargs))

