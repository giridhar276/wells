
import socket
# capturing the hostname of your system
hostname = socket.gethostname()
print(hostname)

ipaddress = socket.gethostbyname("www.google.com")
print(ipaddress)    

import csv
with open("hosts.txt","r") as fobj:
    # converting from file obj to csv object
    reader = csv.reader(fobj)
    for line in reader:
        hostname = line[0]
        ## hostname from ip addresss
        ipaddress = socket.gethostbyname(hostname)
        print(ipaddress)
        

with open("hosts.txt","r") as fobj:
    for line in fobj:
        # strip() wil remove whitespace at both the ends
        line = line.strip()
        hostname = line
        ## hostname from ip addresss
        ipaddress = socket.gethostbyname(hostname)
        print(ipaddress)        