import requests
import json

user = "giridhar276"
password = ""

response = requests.get("https://api.github.com/users")

if response.status_code == 200:
    #print(response.text)
    #converting json to dictionary format
    data = json.loads(response.text)
    for item in data[0:6]:
        print(item['login'])
        
else:
    print("Unable to access REST API")
    
    
 