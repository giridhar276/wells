import csv
import sys
try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        ## convert file obj to csv object
        reader = csv.reader(fobj)
        for line in reader:
            print(line[1])

except FileNotFoundError as error:
    print("System generated error :", error)
    print("Error : file not existing")
except TypeError as err:
    print("System generated error:", err)
    print("Invalid operation")
    print(sys.exc_info())
except Exception as err:a
    print(err)
    print("Default exception")
else:
    output = str(4) + "hello"
finally:
    print("this is always executed")
    
    
## raising exception wantedly

if 1 < 2:
    raise FileNotFoundError("wrong condition")
    
    
    