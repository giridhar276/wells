## inserting one record to db

import pymysql
import time
import csv
try:
    # creating file with today's timestamp
    filename = time.strftime("%d_%B_%Y.csv")    
    #connect database
    fw = open(filename,"w",newline='')
    # converting file object to csv object
    writer = csv.writer(fw)
    db = pymysql.connect(host="127.0.0.1",port=3306,user='root',password='india@123',database = 'wells') 
    #print(db)   # check the connection if successful or not
    if db:
        # for accessing the records
        cursor = db.cursor()
        query = "insert into realestate values('{}','{}')".format("JNTU Road","Hyderabad")
        cursor.execute(query)
        print(cursor.rowcount, " record inserted")
        db.commit()
        

      
except pymysql.InterfaceError as err:
    print(err)
except pymysql.DatabaseError as err:
    print(err)
except pymysql.IntegrityError as err:
    print(err)        
except (pymysql.MySQLError,pymysql.OperationalError) as err:
    print(err)
except Exception as err:
    print(err)