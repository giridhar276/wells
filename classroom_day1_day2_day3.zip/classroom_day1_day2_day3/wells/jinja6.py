#start by importing the Template function from jinja2
from jinja2 import Template

#Set up your jinja template
jtemplate = Template("vlan {{ vlan }}\n name VLAN{{ vlan }}_byJinja\n")

#Create the list of VLANs you want to generate configuration for
vlans = [10,20,30,40,50,60,70,80,90,100]

#Iterate over the list of vlans and print a useable configuration
for vlan in vlans:
    output = jtemplate.render(vlan=vlan)
    print(output)