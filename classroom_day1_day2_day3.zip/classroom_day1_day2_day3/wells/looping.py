
##  for with range()
for val in range(1,11):
    print(val)
    

# for with list
alist = [10,20,40,40,50]
for val in alist:
    print(val)
    
# for with tuple
atup = (45,56,45)
for val in atup:
    print(val)
    
## only keys
book   = {"chap1":10 ,"chap2":20 ,"chap3":30, "chap1":1000}
for key in book.keys():
    print(key)
    
## iterating value
for value in book.values():
    print(value)
    
## display both key-value
for key,value in book.items():
    print(key,value)    

    
#for with set elements  
aset = {10,10,20,20,20,20,30}
for value in aset:
    print(value)




    
    
    
    