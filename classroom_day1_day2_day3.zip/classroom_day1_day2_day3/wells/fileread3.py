# reading from file1 and writing to file2
import csv
# read operation
with open("realestate.csv","r") as fobj:
    ## convert file obj to csv object
    reader = csv.reader(fobj)
    # file write
    with open("SACRAMENTO.csv","w",newline='') as fwrite:
        # object created for writing to the file
        writer = csv.writer(fwrite)
        for line in reader:
            #print(line)
            if "SACRAMENTO" in line :
                writer.writerow(line)