


name = input("Enter any name :")
print("you entered:", name)

# first number
first = int(input("Enter any value:"))
# second number
second = input("Enter any value:")

# typecasting
total = int(first) + int(second)
print(total)