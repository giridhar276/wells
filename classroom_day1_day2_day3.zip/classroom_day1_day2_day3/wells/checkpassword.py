import getpass
print("Enter any password :")
password = getpass.getpass()
print("This is your hidden password :", password)