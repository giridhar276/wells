colors = [
   {
     "colors": "red",
     "values": "#f00"
   },
   {
     "colors": "green",
     "values": "#0f0"
     },
   {
     "colors": "black",
     "values": "#000"
     }
   ]


print(colors)
for item in colors:
    color = item['colors']
    value = item['values']
    print(color,value)
    
    
    
