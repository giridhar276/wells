
# opening the file in write mode
fobj = open("customer.txt","w")
# writing to the file
fobj.write("python programming\n")
# closing the object
fobj.close()


