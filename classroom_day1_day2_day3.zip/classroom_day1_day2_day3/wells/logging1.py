import logging
logging.basicConfig(level=logging.INFO)

def hypotenuse(a, b):
    """Compute the hypotenuse"""
    return (a**2 + b**2)**0.5

a = 3
b = 4
logging.info("Hypotenuse of {a}, {b} is {c}".format(a, b, c=hypotenuse(a,b)))
#> INFO:root:Hypotenuse of 3, 4 is 5.0

