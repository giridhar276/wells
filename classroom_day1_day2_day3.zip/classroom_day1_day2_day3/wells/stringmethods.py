## string is immutable

name = "python programming"

# displaying on the screen... you are modifying the string
print(name.replace("python","ruby"))

print(name)

print(name.capitalize())


print(name.center(40))
print(name.center(40,"*"))
print(name.upper())
print(name.lower())
print(name.islower())
print(name.isalpha())
print(name.endswith("m"))
print(name.endswith("g"))

aname = " python     "
print(len(aname))

aname = aname.strip()  # will remove whitespaces at both the ends
print(len(aname))

