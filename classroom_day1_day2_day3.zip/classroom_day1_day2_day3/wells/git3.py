import requests
import json

 

response = requests.get("https://api.github.com/users",auth=("giridhar276","171271292ab97c83fb8c0fb2461a4ae7f72eb9ab"))

if response.status_code == 200:
    #print(response.text)
    #converting json to dictionary format
    data = json.loads(response.text)
    for item in data[0:6]:
        print(item['login'])
        
else:
    print("Unable to access REST API")
    
    
 