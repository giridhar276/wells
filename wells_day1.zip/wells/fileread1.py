## reading line by line with the object
# fobj can be caled of file object, file handler , file reference
with open("realestate.csv","r") as fobj:
    for line in fobj:
        print(line)
        output = line.split(",")
        print(output)
        
        
## reading the file at a time  
# nore suggested
with open("realestate.csv","r") as fobj:
    print(fobj.read()) 


## reading to the list
with open("realestate.csv","r") as fobj:
    print(fobj.readlines())       

## using csv library
import csv
with open("realestate.csv","r") as fobj:
    ## convert file obj to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line[1])
    
    