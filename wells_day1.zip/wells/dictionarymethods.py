
book   = {"chap1":10 ,"chap2":20 ,"chap3":30, "chap1":1000}

newbook = {"chap5":40,"chap6":60}

## method1
finalbook = { **book,**newbook}
print(finalbook)

## method2 : you are updating newbook to the book
book.update(newbook)
print(book)



print(book.keys())
print(list(book.keys()))

print(book.values())

print(book.items())

# accessing individual element
print(book["chap1"])

#print(book['chap10'])
print(book.get("chap10"))

# key and value of chap1 will be  chap1
print(book.pop("chap1"))
print("After removing :", book)

book.popitem()   # remove some random key:value pair
print(book)

