



for val in range(1,11):
    print("192.168.0.{}".format(val))
    
    
# without using range
fixed = "192.168.0."
for val in range(1,11):
    #concanating
    ip = fixed + str(val)
    print(ip)
    
    
#42    
fixed = "192.168."
for val in range(0,2):
    ipadd= fixed + str(val)
    #print(ipadd)
    for sval in range(1,11):
        print(ipadd + "." + str(sval))
        