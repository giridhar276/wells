

import os

print(os.getcwd())  # pwd

print(os.getpid())  # ps

#os.mkdir("hellotest1")

print(os.listdir())
